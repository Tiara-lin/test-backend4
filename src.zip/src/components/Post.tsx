import React, { useEffect, useRef, useState } from 'react';
import {
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  MoreHorizontal
} from 'lucide-react';
import { useAnalytics } from '../hooks/useAnalytics'; // ✅ 修正匯入路徑

interface Comment {
  username: string;
  text: string;
}

interface PostProps {
  username: string;
  userImage: string;
  location?: string;
  media?: {
    type: 'image' | 'video';
    url: string;
    thumbnail?: string;
  };
  caption: string;
  likes: number;
  timestamp: string;
  comments: Comment[];
}

const Post: React.FC<PostProps> = ({
  username,
  userImage,
  location,
  media,
  caption,
  likes,
  timestamp,
  comments
}) => {
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [comment, setComment] = useState('');
  const [hoverStart, setHoverStart] = useState<number | null>(null);
  const postRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const { trackInteraction, trackPostView } = useAnalytics();
  const postId = `${username}-${timestamp}`;

  const handleLike = () => {
    setIsLiked(!isLiked);
    trackInteraction('like', postId, username);
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    trackInteraction('save', postId, username);
  };

  const handleShare = () => {
    trackInteraction('share', postId, username);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (comment.trim()) {
      trackInteraction('comment', postId, username, { comment });
      setComment('');
    }
  };

  const handleMouseEnter = () => setHoverStart(Date.now());
  const handleMouseLeave = () => {
    if (hoverStart) {
      const duration = (Date.now() - hoverStart) / 1000;
      trackInteraction('hover', postId, username, { duration });
      setHoverStart(null);
    }
  };

  useEffect(() => {
    if (media?.type) {
      const handleScroll = () => {
        if (!postRef.current) return;
        const rect = postRef.current.getBoundingClientRect();
        const viewHeight = window.innerHeight;
        const scrollPct = Math.min(Math.max((viewHeight - rect.top) / rect.height, 0), 1) * 100;
        if (scrollPct >= 50) {
          trackPostView(postId, username, 5.0, scrollPct, media.type);
          window.removeEventListener('scroll', handleScroll);
        }
      };
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
    }
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      const handlePlay = () => trackInteraction('video_play', postId, username);
      const handlePause = () => trackInteraction('video_pause', postId, username);
      video.addEventListener('play', handlePlay);
      video.addEventListener('pause', handlePause);
      return () => {
        video.removeEventListener('play', handlePlay);
        video.removeEventListener('pause', handlePause);
      };
    }
  }, []);

  return (
    <div
      className="border rounded-lg shadow-sm bg-white mb-6 p-4"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      ref={postRef}
    >
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-2">
          <img src={userImage} alt={username} className="w-10 h-10 rounded-full" />
          <div>
            <p className="font-semibold">{username}</p>
            {location && <p className="text-xs text-gray-500">{location}</p>}
          </div>
        </div>
        <MoreHorizontal className="text-gray-500" />
      </div>

      <div className="mb-2">
        {media?.type === 'image' ? (
          <img src={media.url} alt="Post media" className="w-full rounded-lg" />
        ) : (
          <video
            ref={videoRef}
            className="w-full rounded-lg"
            src={media?.url}
            muted
            controls
          />
        )}
      </div>

      <div className="flex items-center justify-between my-2">
        <div className="flex gap-4">
          <Heart
            className={isLiked ? 'text-red-500 fill-red-500' : ''}
            onClick={handleLike}
          />
          <MessageCircle />
          <Send onClick={handleShare} />
        </div>
        <Bookmark
          className={isSaved ? 'text-blue-500 fill-blue-500' : ''}
          onClick={handleSave}
        />
      </div>

      <p className="text-sm mb-1">
        <span className="font-semibold">{username}</span> {caption}
      </p>

      <form onSubmit={handleCommentSubmit} className="flex gap-2 mt-2">
        <input
          type="text"
          className="flex-1 border px-3 py-1 rounded"
          placeholder="Add a comment..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />
        <button
          type="submit"
          className="text-blue-500 font-semibold"
          disabled={!comment.trim()}
        >
          Post
        </button>
      </form>
    </div>
  );
};

export default Post;
